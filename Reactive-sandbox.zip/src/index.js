(function () {
	"use strict";

	//Space for your app

}());