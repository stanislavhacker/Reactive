(function () {
	"use strict";

	//Get css generator
	//noinspection JSUnusedLocalSymbols
	var generator = dom.cssGenerator();

	//Register all root elements
	//�q:
	//generator.register(viewElement);

}());
