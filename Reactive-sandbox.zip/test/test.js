(function () {
	"use strict";

	describe("First bundle", function () {

		it("First test", function () {

		});

	});

}());